from metadata import *
import json,pickle
from collections import defaultdict,Counter
from glob import glob
from data_loader import WikiTables,WDCTables
from elastic import Elastic
from elastic_cache import ElasticCache
from scorer import ScorerMLM
import gensim
import gensim.models.keyedvectors as word2vec
from scipy import sparse
import numpy as np
from scipy.spatial import distance
from sklearn.metrics.pairwise import cosine_similarity

'''
Goal: extract the STR features from new collections

'''

def get_wiki_redirect():
    '''
    '<http://dbpedia.org/resource/Albert_Arnold_Gore/Criticisms>'
    '<http://dbpedia.org/resource/Al_Gore/Criticisms>'
    :return:
    '''
    redir = dict()
    f = open(wiki_dir_path,'r')
    for line in f:
        seps = line.strip().split(' ')
        s = seps[0][29:-1]
        o = seps[2][29:-1]
        if s in redir:
            print(s)
        redir[s] = o
    return redir

def rename_DBentity(entity):
    # <dbpedia:Romance_film> -> Romance_film
    return entity[9:-1]

def get_terms_weights(ec, terms_list, table_id):
    N = ec.doc_count(field="catchall")
    t_weight = {}
    for t1 in terms_list:
        doc_freq = ec.doc_freq(term=t1, field="catchall")
        if doc_freq == 0:
            t_weight[t1] = 0
            continue
        idf = N/doc_freq
        doc_len = ec.doc_length(table_id, field="catchall")
        t_weight[t1] = ec.term_freq(table_id, field="catchall", term=t1) * idf / doc_len
    return t_weight

def vector_sims(q_vecs,t_vecs):
    # early fusion
    C_q = np.mean(q_vecs,axis=0)
    C_t = np.mean(t_vecs,axis=0)
    early_sim = cosine_similarity(C_q.reshape(1,-1),C_t.reshape(1,-1)).flatten()[0]

    pair_sim = cosine_similarity(q_vecs,t_vecs)
    # late max
    max_sim = np.max(pair_sim)
    # late sum
    sum_sim = np.sum(pair_sim)
    # late avg
    avg_sim = np.mean(pair_sim)
    return early_sim,max_sim,sum_sim,avg_sim


def build_entity_matrix():
    f = open(wiki_link_path,'r')
    entity_to_idx = dict()
    rows = []
    cols = []
    for line in f:
        if line[0] == '#':
            continue
        seps = line.strip().split(' ')
        s = seps[0][29:-1]
        o = seps[2][29:-1]
        if s not in entity_to_idx:
            entity_to_idx[s] = len(entity_to_idx)

        if o not in entity_to_idx:
            entity_to_idx[o] = len(entity_to_idx)

        rows.append(entity_to_idx[s])
        cols.append(entity_to_idx[o])

    embd = sparse.csr_matrix((np.ones(len(rows)), (rows, cols)))
    pickle.dump(embd,open(wiki_link_m,'wb'))
    pickle.dump(entity_to_idx,open(wiki_entity_path,'wb'))


def create_STR(test_mode = True):
    #read all q-d pairs from all baselines
    qd_dict = defaultdict(set)
    pool_files = glob(os.path.join(wdc_rank_path,'*'))
    for pool_file in pool_files:
        f = open(pool_file,'r')
        for line in f:
            seps = line.split('\t')
            qid,tid = seps[0],seps[2]
            qd_dict[qid].add(tid)
        f.close()

    wdc_loader = WDCTables(wdc_pool_path)
    wiki_loader = WikiTables(os.path.join(wiki_data_path))
    q_dict = wiki_loader.get_queries()
    q_entities = wiki_loader.get_query_entities()
    db_entities = wdc_loader.get_db_entities()
    rdf2vec = gensim.models.Word2Vec.load(rdf2vec_dump)
    w2v = word2vec.KeyedVectors.load_word2vec_format(word2vec_dump, binary=True)
    boe_emd = pickle.load(open(wiki_link_m,'rb'))
    entity_to_index = pickle.load(open(wiki_entity_path,'rb'))
    redir = get_wiki_redirect()

    # feature extracting
    es = Elastic(index_name=webtable_index_name)
    ec = ElasticCache(webtable_index_name)
    # no title
    fields = ['content', 'textBefore', 'textAfter', 'pageTitle', 'header', 'catchall']

    f_str = open(wdc_STR_path,'w')
    for qid in qd_dict:
        # QUERY FEATURES: q_len
        queries = es.get_text_tokens(q_dict[qid])
        q_features = [len(queries)]

        #prepare semantic features from query side: word2vec, bag-of-entities,rdf2vec
        boe_q = []
        rdf_q = []
        w2v_q = []
        for entity in q_entities[qid]:
            surface = rename_DBentity(entity)
            if surface in entity_to_index: # bag-of-entities,
                boe_q.append(boe_emd[entity_to_index[surface]])

            rdf_name = 'dbr:' + surface # rdf2vec
            if rdf_name in rdf2vec:
                rdf_q.append(rdf2vec[rdf_name])
            elif surface in redir:
                redir_name = redir[surface]
                new_rdf_name = 'dbr:'+redir_name
                if new_rdf_name in rdf2vec:
                    rdf_q.append(rdf2vec[new_rdf_name])


        for q_token in queries: # word2vec
            if q_token in w2v:
                w2v_q.append(w2v[q_token])

        boe_q = sparse.vstack(boe_q)
        rdf_q = np.stack(rdf_q)
        w2v_q = np.stack(w2v_q)
        for tid in qd_dict[qid]:
            # for a query, table pair:
            # query features: idf in fields
            for f in fields:
                doc_ct = ec.num_docs()
                for q_t in queries:
                    df = ec.doc_freq(q_t,f)
                    if df != 0:
                        q_features.append(doc_ct/df)
                    else:
                        q_features.append(0)

            # TABLE FEATURES
            source = es.get_doc(tid)['_source']
            raw_source = json.loads(source['raw_json'])


            num_rows = len(raw_source['relation'])
            cols = list(map(list, zip(*raw_source['relation'])))
            num_cols = len(cols)
            Table_ct = Counter()
            for col in cols:
                Table_ct.update(col)
            num_NULL = Table_ct['']
            tablePageFraction = len(es.get_text_tokens(source['content'])) / len(es.get_text_tokens(source['catchall']))

            # RESULT FOR QUERY-TABLE FEATURES
            t_features = [num_rows,num_cols,num_NULL,tablePageFraction]

            # TABLE-QUERY FEATURES
            # ??? remove empty cells ?

            LC =  Counter(es.get_text_tokens(' '.join(cols[0])))  if len(cols)>0 else None
            hitsLC = sum([LC[q_token] for q_token in queries]) if LC else 0

            SLC = Counter(es.get_text_tokens(' '.join(cols[1]))) if len(cols)>1 else None
            hitsSLC = sum([SLC[q_token] for q_token in queries]) if SLC else 0

            TBody = Counter(es.get_text_tokens(source['content']))  if len(source['content'])>0 else None
            hitsB = sum([TBody[q_token] for q_token in queries]) if TBody else 0

            pgTitle  = Counter(es.get_text_tokens(source['pageTitle']))  if len(source['pageTitle'])>0 else None
            qInPgTitle = sum([pgTitle[q_token] for q_token in queries])/sum(pgTitle.values()) if pgTitle else 0

            field_weights = {
                'content':0.2,
                'textBefore':0.2,
                'textAfter':0.2,
                'pageTitle':0.2,
                'header':0.2,
            }
            params = {"fields": field_weights}
            MLM_sim = ScorerMLM(es,{'text': q_dict[qid]},params).score_doc(tid)

            # RESULT FOR QUERY-TABLE FEATURES
            qt_features = [hitsLC,hitsSLC,hitsB,qInPgTitle,MLM_sim]

            # SEMANTIC FEATURES from BAG-OF-ENTITIES/WORD EMBEDDINGS/ RDF2VEC
            # rdf2vec.wv['dbr:Facebook'].shape
            entities = wdc_loader.get_table_entities(tid)
            # add entities from dbpedia
            new_entities = db_entities[tid]
            for field_entities in new_entities:
                for each in field_entities:
                    entities.append(rename_DBentity(each))

            entities = list(set(entities))

            boe_t = []
            rdf_t = []

            for entity in entities:
                if entity in entity_to_index: # bag-of-entities
                    boe_t.append(boe_emd[entity_to_index[entity]])

                rdf_name = 'dbr:' + entity # rdf2vec
                if rdf_name in rdf2vec:
                    rdf_t.append(rdf2vec[rdf_name])
                elif entity in redir:
                    redir_name = 'dbr:' + redir[entity]
                    if redir_name in rdf2vec:
                        rdf_t.append(rdf2vec[redir_name])

            boe_t = sparse.vstack(boe_t)
            rdf_t = np.stack(rdf_t)

            w2v_t = []
            table_terms = es.get_text_tokens(es.get_text_tokens(source['catchall']))
            table_term_weights = get_terms_weights(ec,table_terms,tid)
            C_t = np.zeros(300)
            for t_term in table_terms:
                if t_term in w2v:
                    w2v_t.append(w2v[t_term])
                    C_t += table_term_weights[t_term]*w2v[t_term]

            C_t = C_t/len(w2v_t)

            q_term_weights = get_terms_weights(ec, queries, tid)
            C_q = np.zeros(300)
            for q_term in queries:
                if q_term in w2v:
                    C_q += q_term_weights[q_term]*w2v[q_term]

            C_q = C_q / len(queries)

            # word2vec based similarities
            w2v_early,w2v_max,w2v_sum,w2v_avg  = vector_sims(w2v_q,w2v_t)
            w2v_early = cosine_similarity(C_q.reshape(1,-1),C_t.reshape(1,-1)).flatten()[0]

            # bag-of-entities based similarities
            boe_early,boe_max,boe_sum,boe_avg = vector_sims(boe_q,boe_t)

            # rdf2vec based similarities
            rdf_early,rdf_max,rdf_sum,rdf_avg = vector_sims(rdf_q,rdf_t)

            # combine all features and write into file
            features = []
            features.extend(t_features)
            features.extend(qt_features)
            features.extend([w2v_early,w2v_max,w2v_sum,w2v_avg])
            features.extend([boe_early,boe_max,boe_sum,boe_avg])
            features.extend([rdf_early,rdf_max,rdf_sum,rdf_avg])
            features = ','.join([str(each) for each in features])
            line = qid+',' + q_dict[qid] + ',' + tid +',' + features +'\n'
            f_str.write(line)
    f_str.close()



#build_entity_matrix()
create_STR(test_mode = True)